Vue.component('department-paginate-drop-down', {
	template: '#tmpl-hrm-department-paginate-drop-down'
});