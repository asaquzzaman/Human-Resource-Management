<div class="hrm-department-edit-btn-wrap">
	<a @click.prevent="departmentEdit()" href="#" class="hrm-edit" data-table_option="hrm_job_title_option" data-id="3"><?php _e( 'Edit', 'hrm' ); ?></a>
</div>