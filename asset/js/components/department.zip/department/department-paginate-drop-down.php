<div class="dataTables_length" id="hrm-data-table_length">
	<label>
		<select name="hrm-data-table_length" aria-controls="hrm-data-table" class="">
			<option value="10"><?php _e( '--Select Pagination--', 'hrm'); ?></option>
			<option value="20"><?php _e( '20', 'hrm'); ?></option>
			<option value="50"><?php _e( '50', 'hrm'); ?></option>
			<option value="100"><?php _e( '100', 'hrm'); ?></option>
			<option value="-1"><?php _e( 'All', 'hrm'); ?></option>
		</select>
	</label>
</div>