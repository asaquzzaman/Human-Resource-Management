<div class="hrm-tbl-action-btn-sibling">
	<a @click.prevent="showHideNewDepartmentForm()" href="#" class="button button-primary"><?php _e( 'Add', 'hrm' ); ?></a>
</div>
