Vue.component('department-search', {
	template: '#tmpl-hrm-department-search'
});